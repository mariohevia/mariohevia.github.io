This folder contains the supplementary material.

The videos in high quality can be found at

https://odysee.com/@AnonymousSupplementaryMaterial:0
